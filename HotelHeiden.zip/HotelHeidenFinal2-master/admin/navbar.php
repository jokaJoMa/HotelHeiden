<nav class="navbar navbar-expand navbar-dark bckg-dark sticky-top">

          <a class="navbar-brand mr-1 align-middle" href="index.php">Admin panel</a>
          
          <!-- Navbar -->
          <ul class="navbar-nav ml-auto mr-0 mr-md-3 my-2 my-md-0">
          	
		      	<li class="active nav-item m-3 font-weight-bold align-middle" ><a href="../zivote.php">Home</a></li>
		        <li class="active nav-item m-3 font-weight-bold  align-middle" ><a href="../logout.php">Logout</a></li>
            
            
         
          </ul>
      
        </nav>