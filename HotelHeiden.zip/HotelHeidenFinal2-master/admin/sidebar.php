<ul class="sidebar bckg-dark navbar-nav">
  
    <li class="nav-item">
        <a class="nav-link text-primary font-weight-bold" href="rooms.php">
        
        <span>Rooms</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link text-primary font-weight-bold" href="addroom.php">
        
        <span>Add room</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link text-primary font-weight-bold" href="opisSoba.php">
        
        <span>Room Category</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link text-primary font-weight-bold" href="dodajKategorija.php">
        
        <span>Add Category</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link text-primary font-weight-bold" href="reservations.php">
        
        <span>Reservations</span>
        </a>
    </li>
    
    

    <li class="nav-item">
        <a class="nav-link text-primary font-weight-bold" href="NewsLetterUsers.php">
        <span>Newsletter users</span>
        </a>
    </li>
</ul>