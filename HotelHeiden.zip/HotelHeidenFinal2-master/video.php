<section>
	<div>
		<video loop muted autoplay poster="slike/s2.jpg" id="video" class="fullscreen-video" style="width:120%; height:auto; margin-left:-10%;">
			<source src="slike/video.mp4" type="video/mp4">
		</video>	
	</div>
</section>

